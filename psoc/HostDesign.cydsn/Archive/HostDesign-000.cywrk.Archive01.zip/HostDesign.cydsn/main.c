#include "project.h"
#include "stdio.h"


int psoc_fpga_xfc;  // state of output strobe
int fpga_psoc_xfc;  // state of input strobe

int rect_full[5][5] = {0};
int x1, y1, x2, y2, fill_color, test_pat_mode, engine_id; //values required for commands




void sendByte(int byte){
    OUT_BYTE_Write(byte);
}

void reg_write(uint8_t bytes[5])
{
    // send each of the 5 bytes, wait until handshake is complete to return
    for(int i = 0; i < 5; i++){
        sendByte(bytes[i]);
        CyDelayCycles(1);
        psoc_fpga_xfc = 1 - psoc_fpga_xfc;
        H2G_STRB_OUT_Write(psoc_fpga_xfc);
        
        while(H2G_STRB_IN_Read() == fpga_psoc_xfc){
            //Idle until incoming handshake is toggled
        }
        CyDelayCycles(1);
        fpga_psoc_xfc = 1 - fpga_psoc_xfc;
    }
}


int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    LCD_Start();
    LCD_ClearDisplay();
    
    char dispVal[1];
    char rcvdStatus[1];

    
    psoc_fpga_xfc = 0;  // state of output strobe
    fpga_psoc_xfc = 0;  // state of output strobe
    
    
    //Send reset signal to Nexys board
    CyDelay(100);
    PSOC_RESET_RAW_Write(1);
    CyDelay(100);
    PSOC_RESET_RAW_Write(0);
    CyDelay(100);
    
    //write initial handshake to Nexys FPGA.
    H2G_STRB_OUT_Write(psoc_fpga_xfc);
    
    //arrays have been preset as globals for now. Later use buttons or potentiometer to get values.
    
rect_full[0][0] = 0x00; //x1 and y1
rect_full[0][1] = 0xc8;
rect_full[0][2] = 0xb0;
rect_full[0][3] = 0x04;
rect_full[0][4] = 0x00;

rect_full[1][0] = 0x01; //x2 and y2
rect_full[1][1] = 0xee;
rect_full[1][2] = 0x52;
rect_full[1][3] = 0x14;
rect_full[1][4] = 0x00;

rect_full[2][0] = 0x02; //color
rect_full[2][1] = 0xe1;
rect_full[2][2] = 0x69;
rect_full[2][3] = 0x14;
rect_full[2][4] = 0x00;

rect_full[3][0] = 0x03; //test pat
rect_full[3][1] = 0x00;
rect_full[3][2] = 0x00;
rect_full[3][3] = 0x00;
rect_full[3][4] = 0x00;

rect_full[4][0] = 0x04; //end id
rect_full[4][1] = 0x00;
rect_full[4][2] = 0x00;
rect_full[4][3] = 0x00;
rect_full[4][4] = 0x00;
    
    for(;;)
    {    
        //display all values given by user (current array to send) and "ready to send" msg
        for(int i = 0; i < 5; i++){
            reg_write(rect_full[i]);
        }

        
        LCD_ClearDisplay();
        LCD_PrintString("Full cmd sent!");
        CyDelay(2000);
    }
    

}
